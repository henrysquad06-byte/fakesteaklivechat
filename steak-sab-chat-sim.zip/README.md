# Steak - Steal a Brainrot (SAB) Chat Simulator 🎮

An interactive log and playback simulator for Steak's "Steal a Brainrot" stream. 
This version dynamically randomizes and generates different chat outcomes and structures each time it is used.

## 📂 Repository Contents
* `index.html` - Web interface that fully proceduralizes or shuffles the chat stream dynamically.
* `chat_generator.js` - Dynamic script to endlessly supply distinct brainrot slang and user messages.

## 🛠️ Quick Start
1. Extract the zip file.
2. Open `index.html` in any browser to launch the live randomized simulation.
